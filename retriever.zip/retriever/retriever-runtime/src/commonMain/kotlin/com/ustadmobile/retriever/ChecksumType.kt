package com.ustadmobile.retriever

enum class ChecksumType() {

    SHA256, MD5

}