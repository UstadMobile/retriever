package com.ustadmobile.retriever

interface RetrieverListener {

    fun onNodeDiscovered()

    fun onNodeLost()

}