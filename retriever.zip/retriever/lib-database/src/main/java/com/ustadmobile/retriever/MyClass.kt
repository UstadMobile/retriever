package com.ustadmobile.retriever

class MyClass {
}